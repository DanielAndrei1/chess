import PawnWhite from './pawnWhite.js';
import PawnBlack from './pawnBlack.js';
import Chess from './chess.js';

// Create instances of the imported classes
const chess = new Chess();
const pawnWhite = new PawnWhite(chess);
const pawnBlack = new PawnBlack(chess, pawnWhite.turn);

pawnWhite.initialize();
pawnBlack.initialise();

$(document).on("click", ".PlayerBlack", function() {
    pawnBlack.setTurn(pawnWhite.getTurn);
    console.log(pawnWhite.getTurn);

    pawnBlack.setPawnBlackValidMovesCounter(pawnWhite.getPawnBlackValidMovesCounter);
    });


$(document).on("click", ".PlayerWhite", function() {
    pawnWhite.setTurn(pawnBlack.getTurn);
    pawnWhite.setPawnWhiteValidMovesCounter(pawnBlack.getPawnWhiteValidMovesCounter);
  });
  
 
