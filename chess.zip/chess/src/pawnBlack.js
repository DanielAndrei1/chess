import * as $ from 'jquery';

class PawnBlack {
  constructor(chess, turn) {
    this.chess = chess;
    this.turn = turn;
  }

  initialise() {
    const chess = this.chess; // Access the chess property using 'this'
    let PawnBlackValidMovesCounter = this.PawnBlackValidMovesCounter;
    let turn = this.turn;
    $(function() {
      let countClickedPieces = 0;
      let PlayerBlack = "PlayerBlack";
      let PawnWhiteValidMovesCounter;
      let nextValidPawnSquare;
      let nextNextValidPawnSquare;
      let rightValidTake;
      let leftValidTake;

      $(document).on("click", ".PlayerBlack", function() {
        if (!turn) {
          console.log(countClickedPieces);

          if ($("div:has(.Active)") && countClickedPieces == 1) {
            $("div").find(".Active").removeClass("Active");
            countClickedPieces -= 1;
            nextValidPawnSquare.off('click');
            nextNextValidPawnSquare.off('click');
          }

          $(this).toggleClass('Active');

          if ($(this).hasClass("PawnBlack")) {
            console.log($('#3g'));
            let currentSquare = $(this);
            let currentPiece = $(this).find("img");
            nextValidPawnSquare = chess.splitId(this, -1, "FowardPawn");
            nextNextValidPawnSquare = chess.splitId(this, -2, "FowardPawn");

            if (!$(nextValidPawnSquare).hasClass("PawnWhite")) {
              nextValidPawnSquare.toggleClass('Active');
              nextNextValidPawnSquare.toggleClass('Active');

              nextValidPawnSquare.on("click", function() {
                if (PawnBlackValidMovesCounter != 2) {
                  chess.addClassesToNextSquare(this, currentPiece, PlayerBlack);
                  chess.removeClassesFromPrevSquare(currentSquare, PlayerBlack);
                  turn = true;
                  nextNextValidPawnSquare.removeClass('Active');
                  PawnBlackValidMovesCounter = 1;
                  PawnWhiteValidMovesCounter = 0;
                }
              });

              nextNextValidPawnSquare.on("click", function() {
                if (PawnBlackValidMovesCounter != 1) {
                  chess.addClassesToNextSquare(this, currentPiece, PlayerBlack);
                  chess.removeClassesFromPrevSquare(currentSquare, PlayerBlack);
                  turn = true;
                  nextValidPawnSquare.removeClass('Active');
                  PawnBlackValidMovesCounter = 2;
                  PawnWhiteValidMovesCounter = 0;
                }
              });
            }

            countClickedPieces += 1;
            console.log(countClickedPieces);
          }
        }
      });
    });
  }

  getTurn(){
    return this.turn;
  }  
  getPawnWhiteValidMovesCounter(){
    return this.PawnWhiteValidMovesCounter;
  }

  setTurn(turn){
    this.turn = turn;
  }
  setPawnBlackValidMovesCounter(PawnBlackValidMovesCounter){
    this.PawnBlackValidMovesCounter = PawnBlackValidMovesCounter; 
  }
}

export default PawnBlack;
