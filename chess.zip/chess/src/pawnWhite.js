import * as $ from 'jquery';

class PawnWhite {
  constructor(chess) {
    this.chess = chess;
    this.turn = true;
  }

  initialize() {
    const chess = this.chess; // Access the chess property using 'this'
    let turn = this.turn;
    $(function() {
      let countClickedPieces = 0;
      let PlayerWhite = "PlayerWhite";
      let PawnWhiteValidMovesCounter = 0;
      let nextValidPawnSquare;
      let nextNextValidPawnSquare;
      let rightValidTake;
      let leftValidTake;
      let PawnBlackValidMovesCounter;
      $("div").find(".White.Pawn").on("click", function() {
        // alert( "Handler for `click` called." );
      });

      $(document).on("click", ".PlayerWhite", function() {
        if (turn) {
          // $(this).css( "border", "3px solid yellow" );

          if ($("div:has(.Active)") && countClickedPieces == 1) {
            $("div").find(".Active").removeClass("Active");
            countClickedPieces -= 1;
            nextValidPawnSquare.off('click');
            nextNextValidPawnSquare.off('click');
            leftValidTake.off('click');
            rightValidTake.off('click');
          }

          $(this).toggleClass('Active');

          if ($(this).hasClass("PawnWhite Active")) {
            console.log($('#3g'));
            let currentSquare = $(this);
            let currentPiece = $(this).find("img");
            nextValidPawnSquare = chess.splitId(this, 1, "FowardPawn");
            nextNextValidPawnSquare = chess.splitId(this, 2, "FowardPawn");
            leftValidTake = chess.splitId(this, 1, "PawnDiagonally", -1);
            rightValidTake = chess.splitId(this, 1, "PawnDiagonally", 1);

            console.log(rightValidTake);

            if ($(leftValidTake).hasClass("PawnBlack")) {
              leftValidTake.toggleClass('Active');
              if (PawnWhiteValidMovesCounter != 2) {

                leftValidTake.on("click", function() {
                  if (PawnWhiteValidMovesCounter != 2) {
                    chess.addClassesToNextSquare(this, currentPiece, PlayerWhite);
                    chess.removeClassesFromPrevSquare(currentSquare, PlayerWhite);
                    turn = false;
                    nextNextValidPawnSquare.removeClass('Active');
                    nextValidPawnSquare.removeClass('Active');
                    PawnWhiteValidMovesCounter = 1;
                    PawnBlackValidMovesCounter = 0;
                    chess.removeClassesToNextSquareDiagonally(this, "PlayerWhite");
                  }
                });

              }
            }

            if ($(rightValidTake).hasClass("PawnBlack")) {
              rightValidTake.toggleClass('Active');

              rightValidTake.on("click", function() {
                if (PawnWhiteValidMovesCounter == 0) {
                  chess.addClassesToNextSquare(this, currentPiece, PlayerWhite);
                  chess.removeClassesFromPrevSquare(currentSquare, PlayerWhite);
                  nextValidPawnSquare.removeClass('Active');
                  turn = false;
                  PawnWhiteValidMovesCounter = 2;
                  PawnBlackValidMovesCounter = 0;

                }
              });

            }

            if (!$(nextValidPawnSquare).hasClass("PawnBlack")) {
              nextValidPawnSquare.toggleClass('Active');
              nextNextValidPawnSquare.toggleClass('Active');

              nextValidPawnSquare.on("click", function() {
                if (PawnWhiteValidMovesCounter != 2) {
                  chess.addClassesToNextSquare(this, currentPiece, PlayerWhite);
                  chess.removeClassesFromPrevSquare(currentSquare, PlayerWhite);
                  turn = false;
                  nextNextValidPawnSquare.removeClass('Active');
                  PawnWhiteValidMovesCounter = 1;
                  PawnBlackValidMovesCounter = 0;
                }
              });

              nextNextValidPawnSquare.on("click", function() {
                if (PawnWhiteValidMovesCounter != 1) {
                  chess.addClassesToNextSquare(this, currentPiece, PlayerWhite);
                  chess.removeClassesFromPrevSquare(currentSquare, PlayerWhite);
                  nextValidPawnSquare.removeClass('Active');
                  turn = false;
                  PawnWhiteValidMovesCounter = 2;
                  PawnBlackValidMovesCounter = 0;

                }
              });

            }

            countClickedPieces += 1;

          }
        }
      });
    });
  }
  getTurn(){
    return this.turn;
  }  
  getPawnBlackValidMovesCounter(){
    return this.PawnBlackValidMovesCounter;
  }

  setTurn(turn){
    this.turn = turn;
  }
  
  setPawnWhiteValidMovesCounter(PawnWhiteValidMovesCounter){
    this.PawnWhiteValidMovesCounter = PawnWhiteValidMovesCounter; 

  }

}

export default PawnWhite;
