# chess
I have created a dynamic chess game using HTML, and PHP, Its not finished.
